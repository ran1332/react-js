const books = [
  {
    id: 1,
    title: "Belajar JavaScript Dasar",
    author: "Andi Prasetyo",
    year: 2021,
    description: "Panduan lengkap untuk pemula yang ingin belajar JavaScript dari nol.",
    image: "https://example.com/images/js-dasar.jpg"
  },
  {
    id: 2,
    title: "React untuk Pemula",
    author: "Dina Sari",
    year: 2022,
    description: "Mengenal konsep dan praktik membuat aplikasi React modern.",
    image: "https://example.com/images/react-pemula.jpg"
  },
  {
    id: 3,
    title: "Panduan CSS Flexbox & Grid",
    author: "Budi Santoso",
    year: 2020,
    description: "Menguasai layout modern menggunakan Flexbox dan Grid.",
    image: "https://example.com/images/css-layout.jpg"
  },
  {
    id: 4,
    title: "Membuat API dengan Node.js",
    author: "Citra Dewi",
    year: 2023,
    description: "Langkah-langkah membangun RESTful API dari awal.",
    image: "https://example.com/images/node-api.jpg"
  },
  {
    id: 5,
    title: "TypeScript untuk Skala Besar",
    author: "Eko Pratama",
    year: 2024,
    description: "Meningkatkan kualitas kode JavaScript dengan TypeScript.",
    image: "https://example.com/images/typescript.jpg"
  },
  {
    id: 6,
    title: "Desain UI/UX Dasar",
    author: "Fajar Maulana",
    year: 2021,
    description: "Prinsip dasar mendesain antarmuka pengguna yang efektif.",
    image: "https://example.com/images/ui-ux.jpg"
  },
  {
    id: 7,
    title: "Algoritma dan Struktur Data",
    author: "Gita Lestari",
    year: 2019,
    description: "Dasar-dasar ilmu komputer untuk meningkatkan logika pemrograman.",
    image: "https://example.com/images/algoritma.jpg"
  },
  {
    id: 8,
    title: "Pengantar Machine Learning",
    author: "Hari Susilo",
    year: 2023,
    description: "Konsep dasar Machine Learning dengan Python.",
    image: "https://example.com/images/ml.jpg"
  },
  {
    id: 9,
    title: "Keamanan Web Modern",
    author: "Indah Permata",
    year: 2022,
    description: "Cara melindungi aplikasi web dari berbagai ancaman.",
    image: "https://example.com/images/security.jpg"
  }
];

export default books;