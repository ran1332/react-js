import Home from './component/Home';
import BookPage from './component/BookPage';
import BookHooksExample from './components/BookHooksExample'; // Akan dibuat di Tahap 3

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home />;
      case 'book':
        return <BookPage />;
      case 'hooks':
        return <BookHooksExample />;
      default:
        return <Home />;
    }
  };

  return (
    <>
      <nav style={{ padding: '10px', background: '#333', color: 'white' }}>
        <button onClick={() => setCurrentPage('home')} style={{ margin: '0 10px' }}>Home</button>
        <button onClick={() => setCurrentPage('book')} style={{ margin: '0 10px' }}>Book List</button>
        <button onClick={() => setCurrentPage('hooks')} style={{ margin: '0 10px' }}>Hooks Example</button>
      </nav>
      {renderPage()}
    </>
  );
}

export default App;