// src/components/BookList.jsx
import BookCard from './BookCard';
import booksData from '../Utils/books'; // Import data buku

const BookList = () => {
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center' }}>
      {/* Menggunakan map() untuk mengulang dan merender data */}
      {booksData.map((book) => (
        // Key HARUS ada dan unik (kita gunakan book.id)
        <BookCard key={book.id} book={book} />
      ))}
    </div>
  );
};

export default BookList;