// src/components/BookHooksExample.jsx
import BookCard from './BookCard';
import initialBooks from '../Utils/books'; // Import data awal

const BookHooksExample = () => {
  // 1. Menggunakan useState untuk mengelola daftar buku
  const [books, setBooks] = useState(initialBooks);
  const [newBookTitle, setNewBookTitle] = useState('');
  const [newBookAuthor, setNewBookAuthor] = useState('');

  const handleAddBook = () => {
    if (newBookTitle.trim() === '' || newBookAuthor.trim() === '') {
      alert('Judul dan Penulis tidak boleh kosong!');
      return;
    }

    // Buat objek buku baru
    const newBook = {
      // ID baru harus unik (gunakan tanggal atau hitungan)
      id: Date.now(), 
      title: newBookTitle,
      author: newBookAuthor,
      year: new Date().getFullYear(),
      description: "Buku baru ditambahkan melalui Hooks.",
      image: "https://via.placeholder.com/300x400?text=Buku+Baru"
    };

    // 2. Menggunakan Spread Operator (...) untuk menambahkan item baru
    // dan membuat array baru (immutability)
    setBooks([...books, newBook]);

    // Bersihkan input
    setNewBookTitle('');
    setNewBookAuthor('');
  };

  return (
    <div>
      <h2>Tambah Buku Baru (Hooks Example)</h2>

      {/* Input dan Button untuk Menambahkan Data */}
      <div style={{ margin: '20px', padding: '15px', border: '1px solid blue' }}>
        <input 
          type="text" 
          placeholder="Judul Buku" 
          value={newBookTitle} 
          onChange={(e) => setNewBookTitle(e.target.value)} 
          style={{ marginRight: '10px', padding: '8px' }}
        />
        <input 
          type="text" 
          placeholder="Penulis" 
          value={newBookAuthor} 
          onChange={(e) => setNewBookAuthor(e.target.value)}
          style={{ marginRight: '10px', padding: '8px' }}
        />
        <button onClick={handleAddBook} style={{ padding: '8px 15px' }}>
          Tambahkan Buku
        </button>
      </div>

      {/* Menampilkan Daftar Buku yang Diperbarui */}
      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center' }}>
        {books.map((book) => (
          <BookCard key={book.id} book={book} />
        ))}
      </div>
    </div>
  );
};

export default BookHooksExample;