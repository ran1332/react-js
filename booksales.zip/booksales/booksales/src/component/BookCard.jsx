const BookCard = ({ book }) => {
  return (
    <div style={{ border: '1px solid #ccc', padding: '10px', margin: '10px', width: '300px' }}>
      <img src={book.image} alt={book.title} style={{ width: '100%', height: 'auto' }} />
      <h3>{book.title}</h3>
      <p>Oleh: {book.author}</p>
      <p>Tahun: {book.year}</p>
      <p>{book.description.substring(0, 100)}...</p>
    </div>
  );
};

export default BookCard;