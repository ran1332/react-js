// src/pages/Home.jsx
import BookList from '../components/BookList';

const Home = () => {
  return (
    <div>
      <h1>Selamat Datang di Toko Buku Kami (Halaman Home)</h1>
      <BookList />
    </div>
  );
};

export default Home;