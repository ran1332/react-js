import Footer from "../shared/Footer";
import Header from "../shared/header";
import ProductList from "../shared/ProductList";



export default function Produk(){
  return (
    <>
        <Header/>
        <ProductList/>
        <Footer/>
    </>
  );
}