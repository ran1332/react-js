import Footer from "../shared/Footer";
import Header from "../shared/header";


export default function About() {
  return (
    <>
        <Header/>
        <Footer/>
    </>
  );
}