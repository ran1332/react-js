export default function Home(){
  
  
return (
  <>  
    <div className="row flex-lg-row-reverse align-items-center g-5 py-5">
    <div className="col-10 col-sm-8 col-lg-6">
        <img 
            src="https://picsum.photos/id/16/1920/1080" 
            className="d-block mx-lg-auto img-fluid" 
            alt="Bootstrap Themes" 
            width="700" 
            height="500" 
            loading="lazy"
        />
    </div>
    
    <div className="col-lg-6">
        
        <h1 className="display-5 fw-bold text-body-emphasis lh-1 mb-3">
            menu liburan tebaru!,ini adalah destinasi keluarga terenakloh.
        </h1>
        
        <p className="lead">
            Nikmati momen berharga bersama keluarga dengan berwisata ke tempat terbaik di Indonesia.  
        Temukan inspirasi liburan, destinasi ramah anak, dan pengalaman seru yang tak terlupakan!
        </p>
        
        <div className="d-grid gap-2 d-md-flex justify-content-md-start">
            <button type="button" className="btn btn-primary btn-lg px-4 me-md-2" fdprocessedid="70jgfy">
                Cek Dulu
            </button>
            <button type="button" className="btn btn-outline-secondary btn-lg px-4" fdprocessedid="0ulwed">
                Kembali
            </button>
        </div>
        
    </div>
</div>
</>
  )
} 