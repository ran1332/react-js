export default function ProductList() {
  const products = [
    {
      id: 1,
      name: "Paket Liburan Bali Keluarga",
      description: "Nikmati keindahan pantai Bali dengan paket 3 hari 2 malam untuk seluruh keluarga.",
      price: "Rp 4.500.000",
      image: "https://source.unsplash.com/https://picsum.photos/id/13/1920/1080400x250/?bali,beach",
    },
    {
      id: 2,
      name: "Petualangan Alam Lembang",
      description: "Rasakan udara segar dan keseruan wisata alam di Lembang dengan aktivitas keluarga.",
      price: "Rp 2.750.000",
      image: "https://source.unsplash.com/400x250/?lembang,foreshttps://picsum.photos/id/15/1920/1080t",
    },
    {
      id: 3,
      name: "Liburan Edukatif Yogyakarta",
      description: "Kunjungi tempat budaya dan edukasi di Yogyakarta. Cocok untuk liburan anak-anak.",
      price: "Rp 3.200.000",
      image: "https://source.unhttps://picsum.photos/id/29/1920/1080splash.com/400x250/?yogyakarta,temple",
    },
  ];

  return (
    <div className="container my-5">
      <h2 className="text-center mb-4">Paket Wisata Keluarga</h2>
      <div className="row">
        {products.map((product) => (
          <div key={product.id} className="col-md-4 mb-4">
            <div className="card h-100 shadow-sm">
              <img
                src={product.image}
                className="card-img-top"
                alt={product.name}
              />
              <div className="card-body d-flex flex-column">
                <h5 className="card-title">{product.name}</h5>
                <p className="card-text flex-grow-1">{product.description}</p>
                <div className="d-flex justify-content-between align-items-center">
                  <span className="fw-bold text-success">{product.price}</span>
                  <a href="#" className="btn btn-primary btn-sm">
                    Pesan Sekarang
                  </a>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
