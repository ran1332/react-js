import Footer from "../shared/Footer";
import Header from "../shared/header";
import Home from "../shared/home";
import ProductList from "../shared/ProductList";

export default function Monocrom() {
  return (
    <>
        <Header/>
        <Home/>
        <ProductList/>
        <Footer/>
    </>
  );
}
