import Footer from "../shared/Footer";
import Header from "../shared/header";

export default function Login() {
  return (
    <>
    <Header/>
    <div className="d-flex align-items-center justify-content-center vh-100 bg-light">
      <div className="card shadow p-4" style={{ width: "100%", maxWidth: "400px" }}>
        <h3 className="text-center mb-4 text-primary">Login Wisata Keluarga</h3>

        <form>
          <div className="mb-3">
            <label htmlFor="email" className="form-label">Email</label>
            <input
              type="email"
              className="form-control"
              id="email"
              placeholder="Masukkan email"
              required
            />
          </div>

          <div className="mb-3">
            <label htmlFor="password" className="form-label">Password</label>
            <input
              type="password"
              className="form-control"
              id="password"
              placeholder="Masukkan password"
              required
            />
          </div>

          <button type="submit" className="btn btn-primary w-100 mb-3">
            Masuk
          </button>

          <p className="text-center text-muted">
            Belum punya akun? <a href="#" className="text-decoration-none">Daftar di sini</a>
          </p>
        </form>
      </div>
    </div>
    <Footer/>
    </>
  );
}
