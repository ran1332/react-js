import Footer from "../shared/Footer";
import Header from "../shared/header";
import Home from "../shared/home";


export default function Filosofi() {
  return (
    <>
        <Header/>
        <Home/>
        <Footer/>
    </>
  );
}