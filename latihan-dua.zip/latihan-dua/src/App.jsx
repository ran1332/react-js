import { BrowserRouter, Routes, Route } from "react-router";
import Monocrom from "./component/pages";
import Produk from "./component/produk/produk";
import Filosofi from "./component/filososi/filosofi";
import About from "./component/about/about";
import Login from "./component/login/login";


function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route index element={<Monocrom/>}/> 
          <Route path="produk" element={<Produk/>}/>
          <Route path="filosofi" element={<Filosofi/>}/>
          <Route path="About" element={<About/>}/>
          <Route path="login" element={<Login/>}/>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;

